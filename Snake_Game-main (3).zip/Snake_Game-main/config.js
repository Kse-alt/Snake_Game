export default class Config {

	constructor() {
		this.step = 0;
		this.maxStep = 6;
		this.sizeCell = 16;
		this.sizeBerry = this.sizeCell / 4;

	}

}
